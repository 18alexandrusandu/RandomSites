package com.example.calatourapp.repository

import com.example.calatourapp.api.Data.LoginRequest
import com.example.calatourapp.api.Data.PiuApi
import java.net.PasswordAuthentication
interface AuthentificationRepository {

    var token:String
    var displayName:String
   suspend fun  login(username:String,password:String):Boolean
   suspend fun logout():Boolean
  suspend  fun globalLogout(username:String,password:String):Boolean
}
object AuthentificationRepositoryImpl:AuthentificationRepository
{
     private val piuApi:PiuApi=PiuApi.create()

    override var token:String=""
    override  var displayName:String=""
    override suspend fun login(username: String, password: String): Boolean {

        try{
            val response=piuApi.authenticate(
                LoginRequest(username,password)
            )
            token=response.token
            displayName=response.displayName

            true
        }catch(e:Exception){
         false
        }
        TODO("Not yet implemented")
    }

    override suspend fun logout(): Boolean {
        try{
            val response=piuApi.logout()

            token=""
            displayName=""

            true
        }catch(e:Exception){
            false
        }
        TODO("Not yet implemented")
    }

    override suspend fun globalLogout(username: String, password: String): Boolean {
        TODO("Not yet implemented")
        try{
            val response=piuApi.globallogout(
                LoginRequest(username,password)
            )
            token=null
            displayName=""

            true
        }catch(e:Exception){
            false
        }
    }

}