package com.example.calatourapp.api.Data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*

val piuApi=PiuApi.create()
const val contentType="Content-Type:application/json"
interface PiuApi
{
    @Headers(contentType)
    @POST("authenticate.php")
    suspend fun authenticate(
        @Body body: LoginRequest
    ):LoginResponse
    @Headers(contentType)
    @DELETE("logout.php")
    suspend fun logout()
    @Headers(contentType)
    @HTTP(method="delete", path="logout.php",hasBody=true)
    suspend fun globallogout(@Body body:LoginRequest)

    @Headers(contentType)
    @POST("sendmessage.php")
    suspend fun sendMessage(
        @Header("Authorization") token: String,
        @Body body:SendMessageRequest  )
    @Headers(contentType)
    @GET("readmessages.php")
    suspend fun  readMessages(

        @Header("Authorization") token: String
    ):ReadMessagesResponse

    companion object{
        private val logger=HttpLoggingInterceptor().apply{
            level=HttpLoggingInterceptor.Level.BODY
        }
        private val httpClient= OkHttpClient.Builder()
        .addInterceptor(logger)
        .build()
        fun create():PiuApi=Retrofit.Builder()
            .baseUrl("http://193.226.17.35/chat-piu/")
            .addConverterFactory(MoshiConverterFactory.create())
            .client(httpClient)
            .build()
            .create(PiuApi::class.java)
            }
}