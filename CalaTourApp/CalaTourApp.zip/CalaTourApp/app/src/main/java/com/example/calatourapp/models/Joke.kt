package com.example.calatourapp.models

import java.util.UUID

data class Joke(
    val id: UUID = UUID.randomUUID(),
    val type: String,
    val setuo: String,
    val delivery: String,
    val isFavorite: Boolean = false
)
