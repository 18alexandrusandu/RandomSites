package com.example.calatourapp.repository

import com.example.calatourapp.api.Data.ChatMessage
import com.example.calatourapp.api.Data.PiuApi
import com.example.calatourapp.api.Data.SendMessageRequest
import java.time.LocalDateTime


interface  ChatRepository
{
   suspend fun readMessages():List<ChatMessage>

    suspend fun sendMessage(message:String):List<ChatMessage>


}

class ChatRepositoryImpl:ChatRepository {
    private val repo:AuthentificationRepository=AuthentificationRepositoryImpl()
    private val piuApi=PiuApi.create()
    private val messages= mutableListOf<ChatMessage>()
   override suspend fun readMessages():List<ChatMessage>
    {
        val remoteMessages=piuApi.readMessages("Bearer"+repo.token)
      return try{
          messages.apply{
             addAll(remoteMessages.messages)
          }
       }catch(e:Exception)
       {

       }

    }
    override  suspend fun sendMessage(message:String):List<ChatMessage>
    {
        return try {
            val newMessage = ChatMessage(
                sender = repo.displayName,
                text = message,
                timestamp = LocalDateTime.now().toString()
            )
            piuApi.sendMessage(
                token = "Bearer: " + repo.token,
                body = SendMessageRequest(message)
            )
            messages.apply {
                add(newMessage)
            }.toList()
        }
        catch(e:Exception)
        {

          messages.toList()
        }
    }
}